const Trash = artifacts.require("Trash");

module.exports = function (deployer) {
  deployer.deploy(Trash);
};
